Thanks for contributing this project!

Please don't forget to use `gofmt` to make your code look good.

Here is the command I use. Please always use the same parameters.

	gofmt -tabs=false -tabwidth=4 -w .
