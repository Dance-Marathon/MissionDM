simplehttp
==========

[![Build Status](https://travis-ci.org/mbanzon/simplehttp.png?branch=master)](https://travis-ci.org/mbanzon/simplehttp)

Simple HTTP library for Go.

This small library adds some utility functions for doing HTTP request and easilly gettings results as
structs from JSON and XML.

Supports alternative `http.Client` instances to support use on Google App Engine.

Examples are coming soon.

The code is released under a 3-clause BSD license. See the LICENSE file for more information.